export const DOMAIN = 'http://127.0.0.1:6000'


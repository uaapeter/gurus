import React from 'react'

function LineThrough() {
    return (
        <span className="line-through">N</span> 
    )
}

export default LineThrough
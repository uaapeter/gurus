import { createSlice } from "@reduxjs/toolkit";

type storeType = {
    users: {
        users: any[]
        selected:any
    }
}
const initialState = {
    users: [],
    selected: null,
}

const userSlice = createSlice({
    name:'users',
    initialState,
    reducers: {

        setUsers: (state, action) => {
            state.users = action.payload
        },
        setSelectedUser: (state, action) => {
            state.selected = action.payload
        },

      
    }
    
}) 


export const { setUsers, setSelectedUser } = userSlice.actions

export const selectUsers = (state:storeType) => state.users.users
export const selectSelectedUser = (state:storeType) => state.users.selected

export default userSlice.reducer
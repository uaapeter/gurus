import PageWrapper from '@/app/components/PageWrapper'
import React from 'react'
import PosForm from './PosForm'
import PosTable from './PosTable'
import { cookies } from 'next/headers'
import { redirect } from 'next/navigation'
import { getProducts } from '@/app/server/productServer'
import { getSavedOrders } from '@/app/server/orderServer'

async function page() {
    const cookieStore = await cookies()
    const hasCookie = cookieStore.has('session')
    if(!hasCookie) return redirect('/sign-in')
    const session = cookieStore.get('session')
    // if(right !=='Admin') return redirect('/')

    const result = await Promise.allSettled([   
        getProducts(session?.value),
        getSavedOrders(session?.value)
    ])

    return (
        <PageWrapper>
            <PosForm 
                products={result[0].status == 'fulfilled' ? result[0].value : []}
            />
            <PosTable pendingsales={result[1].status == 'fulfilled' ? result[1].value :[]} token={`${session?.value}`}/>
        </PageWrapper>
    )
}

export default page
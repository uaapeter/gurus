
'use client'
import GridTab from '@/app/components/GridTab'
import PageWrapper from '@/app/components/PageWrapper'
import { CheckIcon, CreditCardIcon, FaceSmileIcon, } from '@heroicons/react/24/solid'
import { ShoppingCart } from '@mui/icons-material'
import React, {  } from 'react'
import ExpiredTable from './ExpiredTable'

function page() {
    return (
        <PageWrapper>
            <div
                className='flex items-center my-6'
            >
                <p className='text-lg font-semibold text-red-500'>Expiration Notification </p>
            </div>
            <section
                className='grid sm:grid-cols-2 md:grid-cols-4 my-6 gap-x-4'
            >

                <GridTab 
                    title='Expires Today' 
                    icon={
                        <div
                            className='bg-red-500 text-white-light text-sm h-7 w-8 flex items-center justify-center rounded-md'
                        >
                            <ShoppingCart className='w-4 text-white-light'/>
                        </div>
                    } 
                   
                    subTitle={0} 
                    url={'/'}      
                    className=' bg-red-100'          
                
                />
                
                <GridTab 
                    title='Expires In 7 Days' 
                    icon={
                        <div
                            className='bg-red-500 text-white-light text-sm h-7 w-8 flex items-center justify-center rounded-md'
                        >
                            <CreditCardIcon className='w-4 text-white-light'/>
                        </div>
                    } 
                   
                    subTitle={0} 
                    url={'/'}      
                    className=' bg-red-100'          
                
                />

                <GridTab 
                     title='Expires In 3 Month Time' 
                    icon={
                        <div
                            className='bg-orange-400 text-white-light text-sm h-7 w-8 flex items-center justify-center rounded-md'
                        >
                            <FaceSmileIcon className='w-4 text-white-light'/>
                        </div>
                    } 
                   
                    subTitle={0} 
                    url={'/'}      
                    className=' bg-orange-100'          
                
                />
                <GridTab 
                    title='Expires In 6 Month' 
                    icon={
                        <div
                            className='bg-blue-dark text-white-light text-sm h-7 w-8 flex items-center justify-center rounded-md'
                        >
                            <CheckIcon className='w-4 text-white-light'/>
                        </div>
                    } 
                   
                    subTitle={0} 
                    url={'/'}      
                    className=' bg-blue-light'          
                
                />
            </section>

            <section>
                <div
                    className='pb-4 flex flex-col'
                >
                    <p
                        className='text-black font-semibold text-sm'
                    >Expiration Details</p>

                   
                </div>
                <ExpiredTable 
                    stores={[]}
                />
            </section>
        </PageWrapper>
    )
}

export default page
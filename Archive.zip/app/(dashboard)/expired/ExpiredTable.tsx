'use client'
import React, {} from 'react'



function ExpiredTable({stores}: {stores:any[]}) {
    // const isLoading = useSelector(selectIsLoading)
    return (
        <div className="relative overflow-x-auto py-4">
            <table className="w-full text-sm text-left text-gray-500 dark:text-gray-400 bg-white-light">
                <thead className="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
                    <tr className='text-xs'>
                        <td scope="col" className="text-xs font-semibold px-1 border-l-0">
                            S/N
                        </td>
                       
                        <th scope="col" className="px-6 text-xs text-center py-2">
                            Product
                        </th>
                        <th scope="col" className="px-6 text-xs">
                           Stock Qty
                        </th>
                        <th scope="col" className="px-6 text-xs">
                           Supplier
                        </th>
                        <th scope="col" className="px-6 text-xs">
                           Expiry Date
                        </th>
                       
                        <th scope="col" className="px-6 text-xs bg-green-50">
                            Status
                        </th>
                        <th scope="col" className="px-6 text-xs">
                            Actions
                        </th> 
                        {/* 
                        <th scope="col" className="px-6 text-xs">
                            Date joined
                        </th> 
                        <th scope="col" className="px-6 text-xs text-center"> 
                            Action
                        </th>*/}
                    </tr>
                </thead>
                
                <tbody>
                    
                </tbody>
                
            </table>
            {
                stores.length <1 ? 
                
                <div
                    className='w-full items-center flex justify-center text-sm py-4'
                >
                    <p className='text-red-500'>No Records Found</p>
                </div>
                : ''
            }
                
            
        </div>
    )
}

export default ExpiredTable